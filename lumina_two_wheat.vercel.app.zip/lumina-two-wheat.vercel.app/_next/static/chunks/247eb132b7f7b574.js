(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 91915, (e, r, t) => {
    "use strict";

    function n(e, r = {}) {
        if (r.onlyHashChange) return void e();
        let t = document.documentElement;
        if ("smooth" !== t.dataset.scrollBehavior) return void e();
        let a = t.style.scrollBehavior;
        t.style.scrollBehavior = "auto", r.dontForceLayout || t.getClientRects(), e(), t.style.scrollBehavior = a
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "disableSmoothScrollDuringRouteTransition", {
        enumerable: !0,
        get: function() {
            return n
        }
    }), e.r(33525)
}, 68017, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "HTTPAccessFallbackBoundary", {
        enumerable: !0,
        get: function() {
            return i
        }
    });
    let n = e.r(90809),
        a = e.r(43476),
        o = n._(e.r(71645)),
        c = e.r(90373),
        u = e.r(54394);
    e.r(33525);
    let l = e.r(8372);
    class s extends o.default.Component {
        constructor(e) {
            super(e), this.state = {
                triggeredStatus: void 0,
                previousPathname: e.pathname
            }
        }
        componentDidCatch() {}
        static getDerivedStateFromError(e) {
            if ((0, u.isHTTPAccessFallbackError)(e)) return {
                triggeredStatus: (0, u.getAccessFallbackHTTPStatus)(e)
            };
            throw e
        }
        static getDerivedStateFromProps(e, r) {
            return e.pathname !== r.previousPathname && r.triggeredStatus ? {
                triggeredStatus: void 0,
                previousPathname: e.pathname
            } : {
                triggeredStatus: r.triggeredStatus,
                previousPathname: e.pathname
            }
        }
        render() {
            let {
                notFound: e,
                forbidden: r,
                unauthorized: t,
                children: n
            } = this.props, {
                triggeredStatus: o
            } = this.state, c = {
                [u.HTTPAccessErrorStatus.NOT_FOUND]: e,
                [u.HTTPAccessErrorStatus.FORBIDDEN]: r,
                [u.HTTPAccessErrorStatus.UNAUTHORIZED]: t
            };
            if (o) {
                let l = o === u.HTTPAccessErrorStatus.NOT_FOUND && e,
                    s = o === u.HTTPAccessErrorStatus.FORBIDDEN && r,
                    i = o === u.HTTPAccessErrorStatus.UNAUTHORIZED && t;
                return l || s || i ? (0, a.jsxs)(a.Fragment, {
                    children: [(0, a.jsx)("meta", {
                        name: "robots",
                        content: "noindex"
                    }), !1, c[o]]
                }) : n
            }
            return n
        }
    }

    function i({
        notFound: e,
        forbidden: r,
        unauthorized: t,
        children: n
    }) {
        let u = (0, c.useUntrackedPathname)(),
            i = (0, o.useContext)(l.MissingSlotContext);
        return e || r || t ? (0, a.jsx)(s, {
            pathname: u,
            notFound: e,
            forbidden: r,
            unauthorized: t,
            missingSlots: i,
            children: n
        }) : (0, a.jsx)(a.Fragment, {
            children: n
        })
    }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 91798, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "useRouterBFCache", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = e.r(71645);

    function a(e, r) {
        let [t, a] = (0, n.useState)(() => ({
            tree: e,
            stateKey: r,
            next: null
        }));
        if (t.tree === e) return t;
        let o = {
                tree: e,
                stateKey: r,
                next: null
            },
            c = 1,
            u = t,
            l = o;
        for (; null !== u && c < 1;) {
            if (u.stateKey === r) {
                l.next = u.next;
                break
            } {
                c++;
                let e = {
                    tree: u.tree,
                    stateKey: u.stateKey,
                    next: null
                };
                l.next = e, l = e
            }
            u = u.next
        }
        return a(o), o
    }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 39756, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "default", {
        enumerable: !0,
        get: function() {
            return T
        }
    });
    let n = e.r(55682),
        a = e.r(90809),
        o = e.r(43476),
        c = e.r(88540),
        u = a._(e.r(71645)),
        l = n._(e.r(74080)),
        s = e.r(8372),
        i = e.r(87288),
        d = e.r(1244),
        f = e.r(72383),
        p = e.r(56019),
        h = e.r(91915),
        m = e.r(58442),
        g = e.r(68017),
        y = e.r(70725),
        b = e.r(84356),
        P = e.r(41538),
        _ = e.r(91798);
    e.r(74180);
    let v = e.r(61994),
        O = e.r(33906),
        S = l.default.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
        E = ["bottom", "height", "left", "right", "top", "width", "x", "y"];

    function R(e, r) {
        let t = e.getBoundingClientRect();
        return t.top >= 0 && t.top <= r
    }
    class j extends u.default.Component {
        componentDidMount() {
            this.handlePotentialScroll()
        }
        componentDidUpdate() {
            this.props.focusAndScrollRef.apply && this.handlePotentialScroll()
        }
        render() {
            return this.props.children
        }
        constructor(...e) {
            super(...e), this.handlePotentialScroll = () => {
                let {
                    focusAndScrollRef: e,
                    segmentPath: r
                } = this.props;
                if (e.apply) {
                    if (0 !== e.segmentPaths.length && !e.segmentPaths.some(e => r.every((r, t) => (0, p.matchSegment)(r, e[t])))) return;
                    let t = null,
                        n = e.hashFragment;
                    if (n && (t = "top" === n ? document.body : document.getElementById(n) ? ? document.getElementsByName(n)[0]), t || (t = "undefined" == typeof window ? null : (0, S.findDOMNode)(this)), !(t instanceof Element)) return;
                    for (; !(t instanceof HTMLElement) || function(e) {
                            if (["sticky", "fixed"].includes(getComputedStyle(e).position)) return !0;
                            let r = e.getBoundingClientRect();
                            return E.every(e => 0 === r[e])
                        }(t);) {
                        if (null === t.nextElementSibling) return;
                        t = t.nextElementSibling
                    }
                    e.apply = !1, e.hashFragment = null, e.segmentPaths = [], (0, h.disableSmoothScrollDuringRouteTransition)(() => {
                        if (n) return void t.scrollIntoView();
                        let e = document.documentElement,
                            r = e.clientHeight;
                        !R(t, r) && (e.scrollTop = 0, R(t, r) || t.scrollIntoView())
                    }, {
                        dontForceLayout: !0,
                        onlyHashChange: e.onlyHashChange
                    }), e.onlyHashChange = !1, t.focus()
                }
            }
        }
    }

    function w({
        segmentPath: e,
        children: r
    }) {
        let t = (0, u.useContext)(s.GlobalLayoutRouterContext);
        if (!t) throw Object.defineProperty(Error("invariant global layout router not mounted"), "__NEXT_ERROR_CODE", {
            value: "E473",
            enumerable: !1,
            configurable: !0
        });
        return (0, o.jsx)(j, {
            segmentPath: e,
            focusAndScrollRef: t.focusAndScrollRef,
            children: r
        })
    }

    function C({
        tree: e,
        segmentPath: r,
        debugNameContext: t,
        cacheNode: n,
        params: a,
        url: l,
        isActive: f
    }) {
        let h = (0, u.useContext)(s.GlobalLayoutRouterContext);
        if ((0, u.useContext)(v.NavigationPromisesContext), !h) throw Object.defineProperty(Error("invariant global layout router not mounted"), "__NEXT_ERROR_CODE", {
            value: "E473",
            enumerable: !1,
            configurable: !0
        });
        let {
            tree: m
        } = h, g = null !== n.prefetchRsc ? n.prefetchRsc : n.rsc, y = (0, u.useDeferredValue)(n.rsc, g), _ = "object" == typeof y && null !== y && "function" == typeof y.then ? (0, u.use)(y) : y;
        if (!_) {
            if (f) {
                let e = n.lazyData;
                if (null === e) {
                    let t = function e(r, t) {
                            if (r) {
                                let [n, a] = r, o = 2 === r.length;
                                if ((0, p.matchSegment)(t[0], n) && t[1].hasOwnProperty(a)) {
                                    if (o) {
                                        let r = e(void 0, t[1][a]);
                                        return [t[0], { ...t[1],
                                            [a]: [r[0], r[1], r[2], "refetch"]
                                        }]
                                    }
                                    return [t[0], { ...t[1],
                                        [a]: e(r.slice(2), t[1][a])
                                    }]
                                }
                            }
                            return t
                        }(["", ...r], m),
                        a = (0, b.hasInterceptionRouteInCurrentTree)(m),
                        o = Date.now();
                    n.lazyData = e = (0, i.fetchServerResponse)(new URL(l, location.origin), {
                        flightRouterState: t,
                        nextUrl: a ? h.previousNextUrl || h.nextUrl : null
                    }).then(e => ((0, u.startTransition)(() => {
                        (0, P.dispatchAppRouterAction)({
                            type: c.ACTION_SERVER_PATCH,
                            previousTree: m,
                            serverResponse: e,
                            navigatedAt: o
                        })
                    }), e)), (0, u.use)(e)
                }
            }(0, u.use)(d.unresolvedThenable)
        }
        return (0, o.jsx)(s.LayoutRouterContext.Provider, {
            value: {
                parentTree: e,
                parentCacheNode: n,
                parentSegmentPath: r,
                parentParams: a,
                debugNameContext: t,
                url: l,
                isActive: f
            },
            children: _
        })
    }

    function x({
        name: e,
        loading: r,
        children: t
    }) {
        let n;
        if (n = "object" == typeof r && null !== r && "function" == typeof r.then ? (0, u.use)(r) : r) {
            let r = n[0],
                a = n[1],
                c = n[2];
            return (0, o.jsx)(u.Suspense, {
                name: e,
                fallback: (0, o.jsxs)(o.Fragment, {
                    children: [a, c, r]
                }),
                children: t
            })
        }
        return (0, o.jsx)(o.Fragment, {
            children: t
        })
    }

    function T({
        parallelRouterKey: e,
        error: r,
        errorStyles: t,
        errorScripts: n,
        templateStyles: a,
        templateScripts: c,
        template: l,
        notFound: i,
        forbidden: d,
        unauthorized: p,
        segmentViewBoundaries: h
    }) {
        let b = (0, u.useContext)(s.LayoutRouterContext);
        if (!b) throw Object.defineProperty(Error("invariant expected layout router to be mounted"), "__NEXT_ERROR_CODE", {
            value: "E56",
            enumerable: !1,
            configurable: !0
        });
        let {
            parentTree: P,
            parentCacheNode: v,
            parentSegmentPath: S,
            parentParams: E,
            url: R,
            isActive: j,
            debugNameContext: T
        } = b, A = v.parallelRoutes, M = A.get(e);
        M || (M = new Map, A.set(e, M));
        let F = P[0],
            D = null === S ? [e] : S.concat([F, e]),
            k = P[1][e],
            N = k[0],
            I = (0, y.createRouterCacheKey)(N, !0),
            U = (0, _.useRouterBFCache)(k, I),
            H = [];
        do {
            let e = U.tree,
                u = U.stateKey,
                h = e[0],
                b = (0, y.createRouterCacheKey)(h),
                P = M.get(b);
            if (void 0 === P) {
                let e = {
                    lazyData: null,
                    rsc: null,
                    prefetchRsc: null,
                    head: null,
                    prefetchHead: null,
                    parallelRoutes: new Map,
                    loading: null,
                    navigatedAt: -1
                };
                P = e, M.set(b, e)
            }
            let _ = E;
            if (Array.isArray(h)) {
                let e = h[0],
                    r = h[1],
                    t = h[2],
                    n = (0, O.getParamValueFromCacheKey)(r, t);
                null !== n && (_ = { ...E,
                    [e]: n
                })
            }
            let S = function(e) {
                    if ("/" === e) return "/";
                    if ("string" == typeof e)
                        if ("(slot)" === e) return;
                        else return e + "/";
                    return e[1] + "/"
                }(h),
                A = S ? ? T,
                F = void 0 === S ? void 0 : T,
                k = v.loading,
                N = (0, o.jsxs)(s.TemplateContext.Provider, {
                    value: (0, o.jsxs)(w, {
                        segmentPath: D,
                        children: [(0, o.jsx)(f.ErrorBoundary, {
                            errorComponent: r,
                            errorStyles: t,
                            errorScripts: n,
                            children: (0, o.jsx)(x, {
                                name: F,
                                loading: k,
                                children: (0, o.jsx)(g.HTTPAccessFallbackBoundary, {
                                    notFound: i,
                                    forbidden: d,
                                    unauthorized: p,
                                    children: (0, o.jsxs)(m.RedirectBoundary, {
                                        children: [(0, o.jsx)(C, {
                                            url: R,
                                            tree: e,
                                            params: _,
                                            cacheNode: P,
                                            segmentPath: D,
                                            debugNameContext: A,
                                            isActive: j && u === I
                                        }), null]
                                    })
                                })
                            })
                        }), null]
                    }),
                    children: [a, c, l]
                }, u);
            H.push(N), U = U.next
        } while (null !== U) return H
    }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 37457, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "default", {
        enumerable: !0,
        get: function() {
            return u
        }
    });
    let n = e.r(90809),
        a = e.r(43476),
        o = n._(e.r(71645)),
        c = e.r(8372);

    function u() {
        let e = (0, o.useContext)(c.TemplateContext);
        return (0, a.jsx)(a.Fragment, {
            children: e
        })
    }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 93504, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "createRenderSearchParamsFromClient", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = new WeakMap;

    function a(e) {
        let r = n.get(e);
        if (r) return r;
        let t = Promise.resolve(e);
        return n.set(e, t), t
    }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 66996, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "createRenderSearchParamsFromClient", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = e.r(93504).createRenderSearchParamsFromClient;
    ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 6831, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "createRenderParamsFromClient", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = new WeakMap;

    function a(e) {
        let r = n.get(e);
        if (r) return r;
        let t = Promise.resolve(e);
        return n.set(e, t), t
    }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 97689, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "createRenderParamsFromClient", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = e.r(6831).createRenderParamsFromClient;
    ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 42715, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "ReflectAdapter", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    class n {
        static get(e, r, t) {
            let n = Reflect.get(e, r, t);
            return "function" == typeof n ? n.bind(e) : n
        }
        static set(e, r, t, n) {
            return Reflect.set(e, r, t, n)
        }
        static has(e, r) {
            return Reflect.has(e, r)
        }
        static deleteProperty(e, r) {
            return Reflect.deleteProperty(e, r)
        }
    }
}, 76361, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "createDedupedByCallsiteServerErrorLoggerDev", {
        enumerable: !0,
        get: function() {
            return l
        }
    });
    let n = function(e, r) {
        if (e && e.__esModule) return e;
        if (null === e || "object" != typeof e && "function" != typeof e) return {
            default: e
        };
        var t = a(void 0);
        if (t && t.has(e)) return t.get(e);
        var n = {
                __proto__: null
            },
            o = Object.defineProperty && Object.getOwnPropertyDescriptor;
        for (var c in e)
            if ("default" !== c && Object.prototype.hasOwnProperty.call(e, c)) {
                var u = o ? Object.getOwnPropertyDescriptor(e, c) : null;
                u && (u.get || u.set) ? Object.defineProperty(n, c, u) : n[c] = e[c]
            }
        return n.default = e, t && t.set(e, n), n
    }(e.r(71645));

    function a(e) {
        if ("function" != typeof WeakMap) return null;
        var r = new WeakMap,
            t = new WeakMap;
        return (a = function(e) {
            return e ? t : r
        })(e)
    }
    let o = {
            current: null
        },
        c = "function" == typeof n.cache ? n.cache : e => e,
        u = console.warn;

    function l(e) {
        return function(...r) {
            u(e(...r))
        }
    }
    c(e => {
        try {
            u(o.current)
        } finally {
            o.current = null
        }
    })
}, 65932, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    var n = {
        describeHasCheckingStringProperty: function() {
            return u
        },
        describeStringPropertyAccess: function() {
            return c
        },
        wellKnownProperties: function() {
            return l
        }
    };
    for (var a in n) Object.defineProperty(t, a, {
        enumerable: !0,
        get: n[a]
    });
    let o = /^[A-Za-z_$][A-Za-z0-9_$]*$/;

    function c(e, r) {
        return o.test(r) ? `\`${e}.${r}\`` : `\`${e}[${JSON.stringify(r)}]\``
    }

    function u(e, r) {
        let t = JSON.stringify(r);
        return `\`Reflect.has(${e}, ${t})\`, \`${t} in ${e}\`, or similar`
    }
    let l = new Set(["hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "toString", "valueOf", "toLocaleString", "then", "catch", "finally", "status", "displayName", "_debugInfo", "toJSON", "$$typeof", "__esModule"])
}, 83066, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "afterTaskAsyncStorageInstance", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = (0, e.r(90317).createAsyncLocalStorage)()
}, 41643, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "afterTaskAsyncStorage", {
        enumerable: !0,
        get: function() {
            return n.afterTaskAsyncStorageInstance
        }
    });
    let n = e.r(83066)
}, 50999, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    var n = {
        isRequestAPICallableInsideAfter: function() {
            return s
        },
        throwForSearchParamsAccessInUseCache: function() {
            return l
        },
        throwWithStaticGenerationBailoutErrorWithDynamicError: function() {
            return u
        }
    };
    for (var a in n) Object.defineProperty(t, a, {
        enumerable: !0,
        get: n[a]
    });
    let o = e.r(43248),
        c = e.r(41643);

    function u(e, r) {
        throw Object.defineProperty(new o.StaticGenBailoutError(`Route ${e} with \`dynamic = "error"\` couldn't be rendered statically because it used ${r}. See more info here: https://nextjs.org/docs/app/building-your-application/rendering/static-and-dynamic#dynamic-rendering`), "__NEXT_ERROR_CODE", {
            value: "E543",
            enumerable: !1,
            configurable: !0
        })
    }

    function l(e, r) {
        let t = Object.defineProperty(Error(`Route ${e.route} used \`searchParams\` inside "use cache". Accessing dynamic request data inside a cache scope is not supported. If you need some search params inside a cached function await \`searchParams\` outside of the cached function and pass only the required search params as arguments to the cached function. See more info here: https://nextjs.org/docs/messages/next-request-in-use-cache`), "__NEXT_ERROR_CODE", {
            value: "E842",
            enumerable: !1,
            configurable: !0
        });
        throw Error.captureStackTrace(t, r), e.invalidDynamicUsageError ? ? = t, t
    }

    function s() {
        let e = c.afterTaskAsyncStorage.getStore();
        return (null == e ? void 0 : e.rootTaskSpawnPhase) === "action"
    }
}, 69882, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    var n = {
        createPrerenderSearchParamsForClientPage: function() {
            return g
        },
        createSearchParamsFromClient: function() {
            return p
        },
        createServerSearchParamsForMetadata: function() {
            return h
        },
        createServerSearchParamsForServerPage: function() {
            return m
        },
        makeErroringSearchParamsForUseCache: function() {
            return v
        }
    };
    for (var a in n) Object.defineProperty(t, a, {
        enumerable: !0,
        get: n[a]
    });
    let o = e.r(42715),
        c = e.r(67673),
        u = e.r(62141),
        l = e.r(12718),
        s = e.r(63138),
        i = e.r(76361),
        d = e.r(65932),
        f = e.r(50999);

    function p(e, r) {
        let t = u.workUnitAsyncStorage.getStore();
        if (t) switch (t.type) {
            case "prerender":
            case "prerender-client":
            case "prerender-ppr":
            case "prerender-legacy":
                return y(r, t);
            case "prerender-runtime":
                throw Object.defineProperty(new l.InvariantError("createSearchParamsFromClient should not be called in a runtime prerender."), "__NEXT_ERROR_CODE", {
                    value: "E769",
                    enumerable: !1,
                    configurable: !0
                });
            case "cache":
            case "private-cache":
            case "unstable-cache":
                throw Object.defineProperty(new l.InvariantError("createSearchParamsFromClient should not be called in cache contexts."), "__NEXT_ERROR_CODE", {
                    value: "E739",
                    enumerable: !1,
                    configurable: !0
                });
            case "request":
                return b(e, r, t)
        }(0, u.throwInvariantForMissingStore)()
    }
    e.r(42852);
    let h = m;

    function m(e, r) {
        let t = u.workUnitAsyncStorage.getStore();
        if (t) switch (t.type) {
            case "prerender":
            case "prerender-client":
            case "prerender-ppr":
            case "prerender-legacy":
                return y(r, t);
            case "cache":
            case "private-cache":
            case "unstable-cache":
                throw Object.defineProperty(new l.InvariantError("createServerSearchParamsForServerPage should not be called in cache contexts."), "__NEXT_ERROR_CODE", {
                    value: "E747",
                    enumerable: !1,
                    configurable: !0
                });
            case "prerender-runtime":
                var n, a;
                return n = e, a = t, (0, c.delayUntilRuntimeStage)(a, O(n));
            case "request":
                return b(e, r, t)
        }(0, u.throwInvariantForMissingStore)()
    }

    function g(e) {
        if (e.forceStatic) return Promise.resolve({});
        let r = u.workUnitAsyncStorage.getStore();
        if (r) switch (r.type) {
            case "prerender":
            case "prerender-client":
                return (0, s.makeHangingPromise)(r.renderSignal, e.route, "`searchParams`");
            case "prerender-runtime":
                throw Object.defineProperty(new l.InvariantError("createPrerenderSearchParamsForClientPage should not be called in a runtime prerender."), "__NEXT_ERROR_CODE", {
                    value: "E768",
                    enumerable: !1,
                    configurable: !0
                });
            case "cache":
            case "private-cache":
            case "unstable-cache":
                throw Object.defineProperty(new l.InvariantError("createPrerenderSearchParamsForClientPage should not be called in cache contexts."), "__NEXT_ERROR_CODE", {
                    value: "E746",
                    enumerable: !1,
                    configurable: !0
                });
            case "prerender-ppr":
            case "prerender-legacy":
            case "request":
                return Promise.resolve({})
        }(0, u.throwInvariantForMissingStore)()
    }

    function y(e, r) {
        if (e.forceStatic) return Promise.resolve({});
        switch (r.type) {
            case "prerender":
            case "prerender-client":
                var t = e,
                    n = r;
                let a = P.get(n);
                if (a) return a;
                let u = (0, s.makeHangingPromise)(n.renderSignal, t.route, "`searchParams`"),
                    l = new Proxy(u, {
                        get(e, r, t) {
                            if (Object.hasOwn(u, r)) return o.ReflectAdapter.get(e, r, t);
                            switch (r) {
                                case "then":
                                    return (0, c.annotateDynamicAccess)("`await searchParams`, `searchParams.then`, or similar", n), o.ReflectAdapter.get(e, r, t);
                                case "status":
                                    return (0, c.annotateDynamicAccess)("`use(searchParams)`, `searchParams.status`, or similar", n), o.ReflectAdapter.get(e, r, t);
                                default:
                                    return o.ReflectAdapter.get(e, r, t)
                            }
                        }
                    });
                return P.set(n, l), l;
            case "prerender-ppr":
            case "prerender-legacy":
                var i = e,
                    d = r;
                let p = P.get(i);
                if (p) return p;
                let h = Promise.resolve({}),
                    m = new Proxy(h, {
                        get(e, r, t) {
                            if (Object.hasOwn(h, r)) return o.ReflectAdapter.get(e, r, t);
                            if ("string" == typeof r && "then" === r) {
                                let e = "`await searchParams`, `searchParams.then`, or similar";
                                i.dynamicShouldError ? (0, f.throwWithStaticGenerationBailoutErrorWithDynamicError)(i.route, e) : "prerender-ppr" === d.type ? (0, c.postponeWithTracking)(i.route, e, d.dynamicTracking) : (0, c.throwToInterruptStaticGeneration)(e, i, d)
                            }
                            return o.ReflectAdapter.get(e, r, t)
                        }
                    });
                return P.set(i, m), m;
            default:
                return r
        }
    }

    function b(e, r, t) {
        return r.forceStatic ? Promise.resolve({}) : O(e)
    }
    let P = new WeakMap,
        _ = new WeakMap;

    function v(e) {
        let r = _.get(e);
        if (r) return r;
        let t = Promise.resolve({}),
            n = new Proxy(t, {
                get: function r(n, a, c) {
                    return Object.hasOwn(t, a) || "string" != typeof a || "then" !== a && d.wellKnownProperties.has(a) || (0, f.throwForSearchParamsAccessInUseCache)(e, r), o.ReflectAdapter.get(n, a, c)
                }
            });
        return _.set(e, n), n
    }

    function O(e) {
        let r = P.get(e);
        if (r) return r;
        let t = Promise.resolve(e);
        return P.set(e, t), t
    }(0, i.createDedupedByCallsiteServerErrorLoggerDev)(function(e, r) {
        let t = e ? `Route "${e}" ` : "This route ";
        return Object.defineProperty(Error(`${t}used ${r}. \`searchParams\` is a Promise and must be unwrapped with \`await\` or \`React.use()\` before accessing its properties. Learn more: https://nextjs.org/docs/messages/sync-dynamic-apis`), "__NEXT_ERROR_CODE", {
            value: "E848",
            enumerable: !1,
            configurable: !0
        })
    })
}, 74804, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "dynamicAccessAsyncStorageInstance", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = (0, e.r(90317).createAsyncLocalStorage)()
}, 88276, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "dynamicAccessAsyncStorage", {
        enumerable: !0,
        get: function() {
            return n.dynamicAccessAsyncStorageInstance
        }
    });
    let n = e.r(74804)
}, 41489, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    var n = {
        createParamsFromClient: function() {
            return h
        },
        createPrerenderParamsForClientSegment: function() {
            return b
        },
        createServerParamsForMetadata: function() {
            return m
        },
        createServerParamsForRoute: function() {
            return g
        },
        createServerParamsForServerSegment: function() {
            return y
        }
    };
    for (var a in n) Object.defineProperty(t, a, {
        enumerable: !0,
        get: n[a]
    });
    let o = e.r(63599),
        c = e.r(42715),
        u = e.r(67673),
        l = e.r(62141),
        s = e.r(12718),
        i = e.r(65932),
        d = e.r(63138),
        f = e.r(76361),
        p = e.r(88276);

    function h(e, r) {
        let t = l.workUnitAsyncStorage.getStore();
        if (t) switch (t.type) {
            case "prerender":
            case "prerender-client":
            case "prerender-ppr":
            case "prerender-legacy":
                return P(e, r, t);
            case "cache":
            case "private-cache":
            case "unstable-cache":
                throw Object.defineProperty(new s.InvariantError("createParamsFromClient should not be called in cache contexts."), "__NEXT_ERROR_CODE", {
                    value: "E736",
                    enumerable: !1,
                    configurable: !0
                });
            case "prerender-runtime":
                throw Object.defineProperty(new s.InvariantError("createParamsFromClient should not be called in a runtime prerender."), "__NEXT_ERROR_CODE", {
                    value: "E770",
                    enumerable: !1,
                    configurable: !0
                });
            case "request":
                return S(e)
        }(0, l.throwInvariantForMissingStore)()
    }
    e.r(42852);
    let m = y;

    function g(e, r) {
        let t = l.workUnitAsyncStorage.getStore();
        if (t) switch (t.type) {
            case "prerender":
            case "prerender-client":
            case "prerender-ppr":
            case "prerender-legacy":
                return P(e, r, t);
            case "cache":
            case "private-cache":
            case "unstable-cache":
                throw Object.defineProperty(new s.InvariantError("createServerParamsForRoute should not be called in cache contexts."), "__NEXT_ERROR_CODE", {
                    value: "E738",
                    enumerable: !1,
                    configurable: !0
                });
            case "prerender-runtime":
                return _(e, t);
            case "request":
                return S(e)
        }(0, l.throwInvariantForMissingStore)()
    }

    function y(e, r) {
        let t = l.workUnitAsyncStorage.getStore();
        if (t) switch (t.type) {
            case "prerender":
            case "prerender-client":
            case "prerender-ppr":
            case "prerender-legacy":
                return P(e, r, t);
            case "cache":
            case "private-cache":
            case "unstable-cache":
                throw Object.defineProperty(new s.InvariantError("createServerParamsForServerSegment should not be called in cache contexts."), "__NEXT_ERROR_CODE", {
                    value: "E743",
                    enumerable: !1,
                    configurable: !0
                });
            case "prerender-runtime":
                return _(e, t);
            case "request":
                return S(e)
        }(0, l.throwInvariantForMissingStore)()
    }

    function b(e) {
        let r = o.workAsyncStorage.getStore();
        if (!r) throw Object.defineProperty(new s.InvariantError("Missing workStore in createPrerenderParamsForClientSegment"), "__NEXT_ERROR_CODE", {
            value: "E773",
            enumerable: !1,
            configurable: !0
        });
        let t = l.workUnitAsyncStorage.getStore();
        if (t) switch (t.type) {
            case "prerender":
            case "prerender-client":
                let n = t.fallbackRouteParams;
                if (n) {
                    for (let a in e)
                        if (n.has(a)) return (0, d.makeHangingPromise)(t.renderSignal, r.route, "`params`")
                }
                break;
            case "cache":
            case "private-cache":
            case "unstable-cache":
                throw Object.defineProperty(new s.InvariantError("createPrerenderParamsForClientSegment should not be called in cache contexts."), "__NEXT_ERROR_CODE", {
                    value: "E734",
                    enumerable: !1,
                    configurable: !0
                })
        }
        return Promise.resolve(e)
    }

    function P(e, r, t) {
        switch (t.type) {
            case "prerender":
            case "prerender-client":
                {
                    let n = t.fallbackRouteParams;
                    if (n) {
                        for (let a in e)
                            if (n.has(a)) return function(e, r, t) {
                                let n = v.get(e);
                                if (n) return n;
                                let a = new Proxy((0, d.makeHangingPromise)(t.renderSignal, r.route, "`params`"), O);
                                return v.set(e, a), a
                            }(e, r, t)
                    }
                    break
                }
            case "prerender-ppr":
                {
                    let n = t.fallbackRouteParams;
                    if (n) {
                        for (let a in e)
                            if (n.has(a)) return function(e, r, t, n) {
                                let a = v.get(e);
                                if (a) return a;
                                let o = { ...e
                                    },
                                    c = Promise.resolve(o);
                                return v.set(e, c), Object.keys(e).forEach(e => {
                                    i.wellKnownProperties.has(e) || r.has(e) && Object.defineProperty(o, e, {
                                        get() {
                                            let r = (0, i.describeStringPropertyAccess)("params", e);
                                            "prerender-ppr" === n.type ? (0, u.postponeWithTracking)(t.route, r, n.dynamicTracking) : (0, u.throwToInterruptStaticGeneration)(r, t, n)
                                        },
                                        enumerable: !0
                                    })
                                }), c
                            }(e, n, r, t)
                    }
                }
        }
        return S(e)
    }

    function _(e, r) {
        return (0, u.delayUntilRuntimeStage)(r, S(e))
    }
    let v = new WeakMap,
        O = {
            get: function(e, r, t) {
                if ("then" === r || "catch" === r || "finally" === r) {
                    let n = c.ReflectAdapter.get(e, r, t);
                    return ({
                        [r]: (...r) => {
                            let t = p.dynamicAccessAsyncStorage.getStore();
                            return t && t.abortController.abort(Object.defineProperty(Error("Accessed fallback `params` during prerendering."), "__NEXT_ERROR_CODE", {
                                value: "E691",
                                enumerable: !1,
                                configurable: !0
                            })), new Proxy(n.apply(e, r), O)
                        }
                    })[r]
                }
                return c.ReflectAdapter.get(e, r, t)
            }
        };

    function S(e) {
        let r = v.get(e);
        if (r) return r;
        let t = Promise.resolve(e);
        return v.set(e, t), t
    }(0, f.createDedupedByCallsiteServerErrorLoggerDev)(function(e, r) {
        let t = e ? `Route "${e}" ` : "This route ";
        return Object.defineProperty(Error(`${t}used ${r}. \`params\` is a Promise and must be unwrapped with \`await\` or \`React.use()\` before accessing its properties. Learn more: https://nextjs.org/docs/messages/sync-dynamic-apis`), "__NEXT_ERROR_CODE", {
            value: "E834",
            enumerable: !1,
            configurable: !0
        })
    })
}, 47257, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "ClientPageRoot", {
        enumerable: !0,
        get: function() {
            return s
        }
    });
    let n = e.r(43476),
        a = e.r(12718),
        o = e.r(8372),
        c = e.r(71645),
        u = e.r(33906),
        l = e.r(61994);

    function s({
        Component: r,
        serverProvidedParams: t
    }) {
        let s, i;
        if (null !== t) s = t.searchParams, i = t.params;
        else {
            let e = (0, c.use)(o.LayoutRouterContext);
            i = null !== e ? e.parentParams : {}, s = (0, u.urlSearchParamsToParsedUrlQuery)((0, c.use)(l.SearchParamsContext))
        }
        if ("undefined" == typeof window) {
            let t, o, {
                    workAsyncStorage: c
                } = e.r(63599),
                u = c.getStore();
            if (!u) throw Object.defineProperty(new a.InvariantError("Expected workStore to exist when handling searchParams in a client Page."), "__NEXT_ERROR_CODE", {
                value: "E564",
                enumerable: !1,
                configurable: !0
            });
            let {
                createSearchParamsFromClient: l
            } = e.r(69882);
            t = l(s, u);
            let {
                createParamsFromClient: d
            } = e.r(41489);
            return o = d(i, u), (0, n.jsx)(r, {
                params: o,
                searchParams: t
            })
        } {
            let {
                createRenderSearchParamsFromClient: t
            } = e.r(66996), a = t(s), {
                createRenderParamsFromClient: o
            } = e.r(97689), c = o(i);
            return (0, n.jsx)(r, {
                params: c,
                searchParams: a
            })
        }
    }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 92825, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "ClientSegmentRoot", {
        enumerable: !0,
        get: function() {
            return u
        }
    });
    let n = e.r(43476),
        a = e.r(12718),
        o = e.r(8372),
        c = e.r(71645);

    function u({
        Component: r,
        slots: t,
        serverProvidedParams: u
    }) {
        let l;
        if (null !== u) l = u.params;
        else {
            let e = (0, c.use)(o.LayoutRouterContext);
            l = null !== e ? e.parentParams : {}
        }
        if ("undefined" == typeof window) {
            let o, {
                    workAsyncStorage: c
                } = e.r(63599),
                u = c.getStore();
            if (!u) throw Object.defineProperty(new a.InvariantError("Expected workStore to exist when handling params in a client segment such as a Layout or Template."), "__NEXT_ERROR_CODE", {
                value: "E600",
                enumerable: !1,
                configurable: !0
            });
            let {
                createParamsFromClient: s
            } = e.r(41489);
            return o = s(l, u), (0, n.jsx)(r, { ...t,
                params: o
            })
        } {
            let {
                createRenderParamsFromClient: a
            } = e.r(97689), o = a(l);
            return (0, n.jsx)(r, { ...t,
                params: o
            })
        }
    }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
        value: !0
    }), Object.assign(t.default, t), r.exports = t.default)
}, 27201, (e, r, t) => {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), Object.defineProperty(t, "IconMark", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = e.r(43476),
        a = () => "undefined" != typeof window ? null : (0, n.jsx)("meta", {
            name: "«nxt-icon»"
        })
}]);