(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 35451, (e, t, r) => {
    var n = {
            229: function(e) {
                var t, r, n, o = e.exports = {};

                function i() {
                    throw Error("setTimeout has not been defined")
                }

                function u() {
                    throw Error("clearTimeout has not been defined")
                }
                try {
                    t = "function" == typeof setTimeout ? setTimeout : i
                } catch (e) {
                    t = i
                }
                try {
                    r = "function" == typeof clearTimeout ? clearTimeout : u
                } catch (e) {
                    r = u
                }

                function l(e) {
                    if (t === setTimeout) return setTimeout(e, 0);
                    if ((t === i || !t) && setTimeout) return t = setTimeout, setTimeout(e, 0);
                    try {
                        return t(e, 0)
                    } catch (r) {
                        try {
                            return t.call(null, e, 0)
                        } catch (r) {
                            return t.call(this, e, 0)
                        }
                    }
                }
                var s = [],
                    c = !1,
                    a = -1;

                function f() {
                    c && n && (c = !1, n.length ? s = n.concat(s) : a = -1, s.length && d())
                }

                function d() {
                    if (!c) {
                        var e = l(f);
                        c = !0;
                        for (var t = s.length; t;) {
                            for (n = s, s = []; ++a < t;) n && n[a].run();
                            a = -1, t = s.length
                        }
                        n = null, c = !1,
                            function(e) {
                                if (r === clearTimeout) return clearTimeout(e);
                                if ((r === u || !r) && clearTimeout) return r = clearTimeout, clearTimeout(e);
                                try {
                                    r(e)
                                } catch (t) {
                                    try {
                                        return r.call(null, e)
                                    } catch (t) {
                                        return r.call(this, e)
                                    }
                                }
                            }(e)
                    }
                }

                function p(e, t) {
                    this.fun = e, this.array = t
                }

                function h() {}
                o.nextTick = function(e) {
                    var t = Array(arguments.length - 1);
                    if (arguments.length > 1)
                        for (var r = 1; r < arguments.length; r++) t[r - 1] = arguments[r];
                    s.push(new p(e, t)), 1 !== s.length || c || l(d)
                }, p.prototype.run = function() {
                    this.fun.apply(null, this.array)
                }, o.title = "browser", o.browser = !0, o.env = {}, o.argv = [], o.version = "", o.versions = {}, o.on = h, o.addListener = h, o.once = h, o.off = h, o.removeListener = h, o.removeAllListeners = h, o.emit = h, o.prependListener = h, o.prependOnceListener = h, o.listeners = function(e) {
                    return []
                }, o.binding = function(e) {
                    throw Error("process.binding is not supported")
                }, o.cwd = function() {
                    return "/"
                }, o.chdir = function(e) {
                    throw Error("process.chdir is not supported")
                }, o.umask = function() {
                    return 0
                }
            }
        },
        o = {};

    function i(e) {
        var t = o[e];
        if (void 0 !== t) return t.exports;
        var r = o[e] = {
                exports: {}
            },
            u = !0;
        try {
            n[e](r, r.exports, i), u = !1
        } finally {
            u && delete o[e]
        }
        return r.exports
    }
    i.ab = "/ROOT/node_modules/next/dist/compiled/process/", t.exports = i(229)
}, 47167, (e, t, r) => {
    "use strict";
    var n, o;
    t.exports = (null == (n = e.g.process) ? void 0 : n.env) && "object" == typeof(null == (o = e.g.process) ? void 0 : o.env) ? e.g.process : e.r(35451)
}, 45689, (e, t, r) => {
    "use strict";
    var n = Symbol.for("react.transitional.element");

    function o(e, t, r) {
        var o = null;
        if (void 0 !== r && (o = "" + r), void 0 !== t.key && (o = "" + t.key), "key" in t)
            for (var i in r = {}, t) "key" !== i && (r[i] = t[i]);
        else r = t;
        return {
            $$typeof: n,
            type: e,
            key: o,
            ref: void 0 !== (t = r.ref) ? t : null,
            props: r
        }
    }
    r.Fragment = Symbol.for("react.fragment"), r.jsx = o, r.jsxs = o
}, 43476, (e, t, r) => {
    "use strict";
    t.exports = e.r(45689)
}, 90317, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        bindSnapshot: function() {
            return c
        },
        createAsyncLocalStorage: function() {
            return s
        },
        createSnapshot: function() {
            return a
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let i = Object.defineProperty(Error("Invariant: AsyncLocalStorage accessed in runtime where it is not available"), "__NEXT_ERROR_CODE", {
        value: "E504",
        enumerable: !1,
        configurable: !0
    });
    class u {
        disable() {
            throw i
        }
        getStore() {}
        run() {
            throw i
        }
        exit() {
            throw i
        }
        enterWith() {
            throw i
        }
        static bind(e) {
            return e
        }
    }
    let l = "undefined" != typeof globalThis && globalThis.AsyncLocalStorage;

    function s() {
        return l ? new l : new u
    }

    function c(e) {
        return l ? l.bind(e) : u.bind(e)
    }

    function a() {
        return l ? l.snapshot() : function(e, ...t) {
            return e(...t)
        }
    }
}, 42344, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "workAsyncStorageInstance", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = (0, e.r(90317).createAsyncLocalStorage)()
}, 63599, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "workAsyncStorage", {
        enumerable: !0,
        get: function() {
            return n.workAsyncStorageInstance
        }
    });
    let n = e.r(42344)
}, 12354, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "HandleISRError", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    let n = "undefined" == typeof window ? e.r(63599).workAsyncStorage : void 0;

    function o({
        error: e
    }) {
        if (n) {
            let t = n.getStore();
            if (t ? .isStaticGeneration) throw e && console.error(e), e
        }
        return null
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 68027, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function() {
            return l
        }
    });
    let n = e.r(43476),
        o = e.r(12354),
        i = {
            fontFamily: 'system-ui,"Segoe UI",Roboto,Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji"',
            height: "100vh",
            textAlign: "center",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center"
        },
        u = {
            fontSize: "14px",
            fontWeight: 400,
            lineHeight: "28px",
            margin: "0 8px"
        },
        l = function({
            error: e
        }) {
            let t = e ? .digest;
            return (0, n.jsxs)("html", {
                id: "__next_error__",
                children: [(0, n.jsx)("head", {}), (0, n.jsxs)("body", {
                    children: [(0, n.jsx)(o.HandleISRError, {
                        error: e
                    }), (0, n.jsx)("div", {
                        style: i,
                        children: (0, n.jsxs)("div", {
                            children: [(0, n.jsxs)("h2", {
                                style: u,
                                children: ["Application error: a ", t ? "server" : "client", "-side exception has occurred while loading ", window.location.hostname, " (see the", " ", t ? "server logs" : "browser console", " for more information)."]
                            }), t ? (0, n.jsx)("p", {
                                style: u,
                                children: `Digest: ${t}`
                            }) : null]
                        })
                    })]
                })]
            })
        };
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}]);